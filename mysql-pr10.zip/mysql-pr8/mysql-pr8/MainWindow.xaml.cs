﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using MySqlConnector;
using System.Windows.Markup;


namespace mysql_pr8
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MySqlConnection conn;
        public DataRowView data;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM kliyenty", conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            DataGrd1.ItemsSource = dt.DefaultView;
            

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (DataGrd1.SelectedIndex != -1)
            {
                data = DataGrd1.SelectedItem as DataRowView;
                MySqlCommand comma = new MySqlCommand($"DELETE FROM pokupka WHERE ID_kliyent = '{data["ID_kliyent"].ToString()}'", conn);
                comma.ExecuteNonQuery();
                MySqlCommand command = new MySqlCommand($"DELETE FROM kliyenty WHERE ID_kliyent = '{data["ID_kliyent"].ToString()}'", conn);
                command.ExecuteNonQuery();
                UpdateGrid();
            }
            else
            {
                MessageBox.Show("Выбирите нужную запись!");
            }

        }
        public void UpdateGrid()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM kliyenty", conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            DataGrd1.ItemsSource = dt.DefaultView;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            redKlin mainWindow = new redKlin();
            this.Close();
            mainWindow.ShowDialog();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (DataGrd1.SelectedIndex != -1)
            {
                redKlin window = new redKlin();
                window.data = DataGrd1.SelectedItem as DataRowView;
                this.Close();
                window.ShowDialog();
            }

        }
    }
}
