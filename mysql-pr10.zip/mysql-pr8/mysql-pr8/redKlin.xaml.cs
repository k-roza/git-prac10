﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySqlConnector;


namespace mysql_pr8
{
    /// <summary>
    /// Логика взаимодействия для redKlin.xaml
    /// </summary>
    public partial class redKlin : Window
    {
        MySqlConnection conn;
        public DataRowView data;
        public redKlin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command1 = new MySqlCommand($"INSERT INTO kliyenty VALUES('{t1.Text}', '{t2.Text}', '{t3.Text}', '{t4.Text}', '{t5.Text}','{t6.Text}', 0)", conn);
            command1.ExecuteNonQuery();
            MessageBox.Show("Данные введены успешно");
            MainWindow window2 = new MainWindow();
            this.Close();
            window2.ShowDialog();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (data != null)
            {
                t1.Text = data["ID_kliyent"].ToString();
                t2.Text = data["FIO"].ToString();
                t3.Text = data["Telephone"].ToString();
                t4.Text = data["Seriya_pasporta"].ToString();
                t5.Text = data["Number_pasporta"].ToString();
                t6.Text = data["Home_adres"].ToString();
            }

        }


        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command = new MySqlCommand($"UPDATE kliyenty SET ID_kliyent = {t1.Text}, FIO = '{t2.Text}', Telephone = '{t3.Text}', Seriya_pasporta = '{t4.Text}', Number_pasporta = '{t5.Text}', Home_adres = '{t6.Text}' WHERE ID_kliyent = {t1.Text}", conn);
            command.ExecuteNonQuery();
            MessageBox.Show("Обновление выполнено! Переход на главное окно!");
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.ShowDialog();

        }
    }
}
