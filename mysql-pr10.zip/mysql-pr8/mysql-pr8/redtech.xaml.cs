﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySqlConnector;

namespace mysql_pr8
{
    /// <summary>
    /// Логика взаимодействия для redtech.xaml
    /// </summary>
    public partial class redtech : Window
    {
        MySqlConnection conn;
        public DataRowView data;
        public redtech()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command1 = new MySqlCommand($"INSERT INTO technical_data VALUES('{t1.Text}', '{t2.Text}', '{t3.Text}', '{t4.Text}', '{t5.Text}','{t6.Text}', '{t7.Text}')", conn);
            command1.ExecuteNonQuery();
            MessageBox.Show("Данные введены успешно");
            Window3 window2 = new Window3();
            this.Close();
            window2.ShowDialog();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (data != null)
            {
                t1.Text = data["ID_tovara"].ToString();
                t2.Text = data["Tip_kuzova"].ToString();
                t3.Text = data["Kol_dverey"].ToString();
                t4.Text = data["kol_mest"].ToString();
                t5.Text = data["Tip_dvigatel"].ToString();
                t6.Text = data["Raspolozh_dvigatel"].ToString();
                t7.Text = data["Obyem_dvigatel"].ToString();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command = new MySqlCommand($"UPDATE technical_data SET ID_tovara = {t1.Text}, Tip_kuzova = '{t2.Text}', Kol_dverey = {t3.Text}, kol_mest = {t4.Text}, Tip_dvigatel = '{t5.Text}', Raspolozh_dvigatel = '{t6.Text}', Obyem_dvigatel = '{t7.Text}' WHERE ID_tovara = {t1.Text}", conn);
            command.ExecuteNonQuery();
            MessageBox.Show("Обновление выполнено!");
            Window3 mainWindow = new Window3();
            this.Close();
            mainWindow.ShowDialog();
        }
    }
}
