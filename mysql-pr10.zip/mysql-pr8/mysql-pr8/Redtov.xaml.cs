﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySqlConnector;

namespace mysql_pr8
{
    /// <summary>
    /// Логика взаимодействия для Redtov.xaml
    /// </summary>
    public partial class Redtov : Window
    {
        MySqlConnection conn;
        public DataRowView data;
        public Redtov()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command1 = new MySqlCommand($"INSERT INTO tovar VALUES('{t1.Text}', '{t2.Text}', '{t3.Text}', '{t4.Text}', '{t5.Text}','{t6.Text}', '{t7.Text}','{t8.Text}' )", conn);
            command1.ExecuteNonQuery();
            MessageBox.Show("Данные введены успешно");
            Window2 window2 = new Window2();
            this.Close();
            window2.ShowDialog();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (data != null)
            {
                t1.Text = data["ID_tovara"].ToString();
                t2.Text = data["Strana_izgotovitel"].ToString();
                t3.Text = data["Marka"].ToString();
                t4.Text = data["Model"].ToString();
                t5.Text = data["Color"].ToString();
                t6.Text = data["Nalichie"].ToString();
                t7.Text = data["Kogda_budet"].ToString();
                t8.Text = data["Price"].ToString();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; User id=root; password=root; database=roza");
            conn.Open();
            MySqlCommand command = new MySqlCommand($"UPDATE tovar SET ID_tovara = {t1.Text}, Strana_izgotovitel = '{t2.Text}', Marka = '{t3.Text}', Model = '{t4.Text}', Color = '{t5.Text}', Nalichie = '{t6.Text}', Kogda_budet = '{t7.Text}', Price = '{t8.Text}' WHERE ID_tovara = {t1.Text}", conn);
            command.ExecuteNonQuery();
            MessageBox.Show("Обновление выполнено!");
            Window2 mainWindow = new Window2();
            this.Close();
            mainWindow.ShowDialog();
        }
    }
}
